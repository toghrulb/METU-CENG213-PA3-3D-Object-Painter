
#include "MeshGraph.h"
#include "BinaryHeap.h"

// For printing
#include <fstream>
#include <iostream>
#include <sstream>

MeshGraph::MeshGraph(const std::vector<Double3>& vertexPositions,
                     const std::vector<IdPair>& edges)
{
    vertices.resize(vertexPositions.size());
    adjList.resize(vertexPositions.size());
    for(int i = 0; i<vertexPositions.size(); i++){
        vertices[i].id = i;
        vertices[i].position3D = vertexPositions[i];
    }
    for(int i = 0; i<edges.size(); i++){
        adjList[edges[i].vertexId0].push_back(&vertices[edges[i].vertexId1]);
        adjList[edges[i].vertexId1].push_back(&vertices[edges[i].vertexId0]);
    }
}

double MeshGraph::AverageDistanceBetweenVertices() const
{
    double sum = 0;
    int c = 0;
    for(int i = 0; i<vertices.size(); i++){
        for(std::list<Vertex*>::const_iterator it = adjList[i].begin(); it!=adjList[i].end(); ++it){
            Vertex* vertex = *it;
            sum+=Double3::Distance(vertices[i].position3D, vertex->position3D);
            c++;
            
        }
    }
    return sum/c;
}

double MeshGraph::AverageEdgePerVertex() const
{
    double c = 0;
    for(int i = 0; i<vertices.size(); i++){
        for(std::list<Vertex*>::const_iterator it = adjList[i].begin(); it!=adjList[i].end(); ++it){
            c++;
        }
    }
    return c/vertices.size()/2;
}

int MeshGraph::TotalVertexCount() const
{
    return vertices.size();
}

int MeshGraph::TotalEdgeCount() const
{
    int c = 0;
    for(int i = 0; i<adjList.size(); i++){
        for(std::list<Vertex*>::const_iterator it = adjList[i].begin(); it!=adjList[i].end(); ++it){
            c++;
        }
    }
    return c/2;
}

int MeshGraph::VertexEdgeCount(int vertexId) const
{
    if(vertexId < adjList.size() && vertexId >= 0)
        return adjList[vertexId].size();
    else
        return -1;
}

void MeshGraph::ImmediateNeighbours(std::vector<int>& outVertexIds,
                                    int vertexId) const
{
    if(vertexId >= 0 || vertexId < vertices.size()){
        for(std::list<Vertex*>::const_iterator it = adjList[vertexId].begin(); it!=adjList[vertexId].end(); ++it)
            outVertexIds.push_back((*it)->id);
    }
}

void MeshGraph::PaintInBetweenVertex(std::vector<Color>& outputColorAllVertex,
                                     int vertexIdFrom, int vertexIdTo,
                                     const Color& color) const
{
    if(vertexIdFrom>=0 && vertexIdFrom<vertices.size() && vertexIdTo>=0 && vertexIdTo<vertices.size()){
        std::vector<int> Prev;
        std::vector<bool> Passed;
        std::vector<double> Distances;
        BinaryHeap Shortest;
        Prev.resize(vertices.size(), -1);
        Passed.resize(vertices.size(), false);
        outputColorAllVertex.resize(vertices.size());
        Distances.resize(vertices.size(), INFINITY);
        Distances[vertexIdFrom] = 0;
        for(int i = 0; i<vertices.size(); i++){
            outputColorAllVertex[i].r = 0;
            outputColorAllVertex[i].g = 0;
            outputColorAllVertex[i].b = 0;
            Shortest.Add(i, Distances[i]);
        }
        int MinId;
        double MinDist;
        Prev[vertexIdFrom] = vertexIdFrom;
        for(int count = 0; count<vertices.size()-1; count++){
            while(true){
                Shortest.PopHeap(MinId, MinDist);
                if(Passed[MinId] == false)
                    break;
            }
            Passed[MinId] = true;
            for(std::list<Vertex*>::const_iterator it = adjList[MinId].begin(); it!=adjList[MinId].end(); ++it){
                if(!Passed[(*it)->id] && Distances[MinId] + Double3::Distance(vertices[MinId].position3D, vertices[(*it)->id].position3D) < Distances[(*it)->id]){
                    Distances[(*it)->id] = Distances[MinId] + Double3::Distance(vertices[MinId].position3D, vertices[(*it)->id].position3D);
                    Prev[(*it)->id] = MinId;
                    Shortest.ChangePriority((*it)->id, Distances[(*it)->id]);
                }
            }
        }
        
        int u = vertexIdTo;
        while(u!=vertexIdFrom){
            outputColorAllVertex[u].r = color.r;
            outputColorAllVertex[u].g = color.g;
            outputColorAllVertex[u].b = color.b;
            u = Prev[u];
        }
        outputColorAllVertex[u].r = color.r;
        outputColorAllVertex[u].g = color.g;
        outputColorAllVertex[u].b = color.b;
    }
}

void MeshGraph::PaintInRangeGeodesic(std::vector<Color>& outputColorAllVertex,
                                    int vertexId, const Color& color,
                                    int maxDepth, FilterType type,
                                    double alpha) const
{
    if(vertexId>=0 && vertexId<vertices.size()){
        std::vector<int> Jump;
        std::vector<bool> Passed;
        BinaryHeap Shortest;
        std::vector<int> Prev;
        Passed.resize(vertices.size(), false);
        outputColorAllVertex.resize(vertices.size());
        Jump.resize(vertices.size(), INFINITY);
        Prev.resize(vertices.size(), -1);
        Jump[vertexId] = 0;
        Prev[vertexId] = vertexId;
        for(int i = 0; i<vertices.size(); i++){
            outputColorAllVertex[i].r = 0;
            outputColorAllVertex[i].g = 0;
            outputColorAllVertex[i].b = 0;
            Shortest.Add(i, Jump[i]);
        }
        int MinId; int order = 1;
        double MinDist;
        while(!Shortest.isEmpty()){
            while(1){    
                Shortest.PopHeap(MinId, MinDist);
                if(!Passed[MinId])
                    break;
            }
            Passed[MinId] = true;
            std::vector<int> Neigh;
            ImmediateNeighbours(Neigh, MinId);
            for(int i = 0; i<Neigh.size(); i++)
                for(int j = 0; j<Neigh.size()-1; j++){
                    if(Neigh[j] > Neigh[j+1]){
                        int temp;
                        temp = Neigh[j];
                        Neigh[j] = Neigh[j+1];
                        Neigh[j+1] = temp;
                    }
                }
                
            for(int i = 0; i<Neigh.size(); i++){
                if(!Passed[Neigh[i]] && (Jump[MinId] + 1) < Jump[Neigh[i]]){
                    Jump[Neigh[i]] = Jump[MinId] + 1;
                    Prev[Neigh[i]] = MinId;
                    Shortest.ChangePriority(Neigh[i], order);
                }
                order++;
            }
        }
        
        for(int i = 0; i<vertices.size(); i++){
            if(Jump[i]<=maxDepth){
                double distance = 0;
                int u = i;
                while(u!=vertexId){
                    distance += Double3::Distance(vertices[u].position3D, vertices[Prev[u]].position3D);
                    u = Prev[u];
                }
                if(type == FILTER_BOX){
                    if(distance <= alpha && distance >= (-alpha)){
                        outputColorAllVertex[i].r = color.r;
                        outputColorAllVertex[i].g = color.g;
                        outputColorAllVertex[i].b = color.b;
                    }
                    else;
                }
                else{
                    outputColorAllVertex[i].r = color.r * std::exp(-pow(distance, 2)/pow(alpha, 2));
                    outputColorAllVertex[i].g = color.g * std::exp(-pow(distance, 2)/pow(alpha, 2));
                    outputColorAllVertex[i].b = color.b * std::exp(-pow(distance, 2)/pow(alpha, 2));
                }
            }
        }
    }
}
void MeshGraph::PaintInRangeEuclidian(std::vector<Color>& outputColorAllVertex,
                                      int vertexId, const Color& color,
                                      int maxDepth, FilterType type,
                                      double alpha) const
{
    if(vertexId>=0 && vertexId<vertices.size()){
        std::vector<int> Jump;
        BinaryHeap Shortest;
        outputColorAllVertex.resize(vertices.size());
        Jump.resize(vertices.size(), INFINITY);
        Jump[vertexId] = 0;
        for(int i = 0; i<vertices.size(); i++){
            outputColorAllVertex[i].r = 0;
            outputColorAllVertex[i].g = 0;
            outputColorAllVertex[i].b = 0;
            Shortest.Add(i, Jump[i]);
        }
        int MinId;
        double MinDist;
        while(!Shortest.isEmpty()){
                Shortest.PopHeap(MinId, MinDist);
            for(std::list<Vertex*>::const_iterator it = adjList[MinId].begin(); it!=adjList[MinId].end(); ++it){
                if(Jump[MinId] + 1 < Jump[(*it)->id]){
                    Jump[(*it)->id] = Jump[MinId] + 1;
                    Shortest.ChangePriority((*it)->id, Jump[(*it)->id]);
                }
            }
        }
        
        for(int i = 0; i<vertices.size(); i++){
            if(Jump[i]<=maxDepth){
                double distance = Double3::Distance(vertices[i].position3D, vertices[vertexId].position3D);
                if(type == FILTER_BOX){
                    if(distance <= alpha && distance >= (-alpha)){
                        outputColorAllVertex[i].r = color.r;
                        outputColorAllVertex[i].g = color.g;
                        outputColorAllVertex[i].b = color.b;
                    }
                    else;
                }
                else{
                    outputColorAllVertex[i].r = color.r * std::exp(-pow(distance, 2)/pow(alpha, 2));
                    outputColorAllVertex[i].g = color.g * std::exp(-pow(distance, 2)/pow(alpha, 2));
                    outputColorAllVertex[i].b = color.b * std::exp(-pow(distance, 2)/pow(alpha, 2));
                }
            }
        }
    }
}
void MeshGraph::WriteColorToFile(const std::vector<Color>& colors,
                                 const std::string& fileName)
{
    // IMPLEMENTED
    std::stringstream s;
    for(int i = 0; i < static_cast<int>(colors.size()); i++)
    {
        int r = static_cast<int>(colors[i].r);
        int g = static_cast<int>(colors[i].g);
        int b = static_cast<int>(colors[i].b);

        s << r << ", " << g << ", " << b << "\n";
    }
    std::ofstream f(fileName.c_str());
    f << s.str();
}

void MeshGraph::PrintColorToStdOut(const std::vector<Color>& colors)
{
    // IMPLEMENTED
    for(int i = 0; i < static_cast<int>(colors.size()); i++)
    {
        std::cout << static_cast<int>(colors[i].r) << ", "
                  << static_cast<int>(colors[i].g) << ", "
                  << static_cast<int>(colors[i].b) << "\n";
    }
}