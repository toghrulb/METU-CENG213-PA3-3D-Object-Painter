#include "BinaryHeap.h"

BinaryHeap::BinaryHeap()
{
    size = 0;
}


bool BinaryHeap::Add(int uniqueId, double weight)
{
    HeapElement n;
    n.uniqueId = uniqueId;
    n.weight = weight;
    for(int i=0; i<elements.size(); i++)
        if(elements[i].uniqueId == uniqueId)
            return false;
    elements.push_back(n);

    int elem = elements.size() - 1;
    while (elem > 0)
    {
        int parent = (elem-1) / 2;
        if (elements[elem].weight < elements[parent].weight)
        {
            HeapElement temp = elements[elem];
            elements[elem] = elements[parent];
            elements[parent] = temp;
            elem = parent;
        }
        else
            break;
    }
    size++;
    return true;
}

bool BinaryHeap::PopHeap(int& outUniqueId, double& outWeight)
{
    if (elements.empty())
        return false;

    outUniqueId = elements[0].uniqueId;
    outWeight = elements[0].weight;

    elements[0] = elements.back();
    elements.pop_back();

    int elem = 0;
    while (true)
    {
        int left = 2 * elem + 1;
        if (left >= (int)elements.size())
            break;

        int right = 2 * elem + 2;
        if (right >= (int)elements.size())
        {
            if (elements[elem].weight > elements[left].weight)
            {
                HeapElement temp = elements[elem];
                elements[elem] = elements[left];
                elements[left] = temp;
                elem = left;
            }
            else
                break;
        }
        else
        {
            int smallest;
            if (elements[left].weight > elements[right].weight)
                smallest = right;
            else
                smallest = left;
            if (elements[elem].weight > elements[smallest].weight)
            {
                HeapElement temp = elements[elem];
                elements[elem] = elements[smallest];
                elements[smallest] = temp;
                elem = smallest;
            }
            else
                break;
        }
    }
    size--;
    return true;
}

bool BinaryHeap::ChangePriority(int uniqueId, double newWeight)
{
    int j=-1;
    for(int i=0; i<elements.size(); i++)
        if(elements[i].uniqueId == uniqueId){
            elements[i].weight = newWeight; j=i;
        }
    if(j==-1) return false;
    
    int elem = j;
    while (elem > 0)
    {
        int parent = (elem-1) / 2;
        if (elements[elem].weight < elements[parent].weight)
        {
            HeapElement temp = elements[elem];
            elements[elem] = elements[parent];
            elements[parent] = temp;
            elem = parent;
        }
        else
            break;
    }
    
    elem = j;
    while (true)
    {
        int left = 2 * elem + 1;
        
        if (left >= (int)elements.size())
            break;

        int right = 2 * elem + 2;
        if (right >= (int)elements.size())
        {
            if (elements[elem].weight > elements[left].weight)
            {
                HeapElement temp = elements[elem];
                elements[elem] = elements[left];
                elements[left] = temp;
                elem = left;
            }
            else
                break;
        }
        else
        {
            int smallest;
            if (elements[left].weight > elements[right].weight)
                smallest = right;
            else
                smallest = left;

            if (elements[elem].weight > elements[smallest].weight)
            {
                HeapElement temp = elements[elem];
                elements[elem] = elements[smallest];
                elements[smallest] = temp;
                elem = smallest;
            }
            else
                break;
        }
    }

    return true;
}
double BinaryHeap::GetWeight(int uniqueId){
    for(int i=0; i<elements.size(); i++)
        if(elements[i].uniqueId == uniqueId)
            return elements[i].weight;
}
bool BinaryHeap::isEmpty(){
    return size == 0;
}
int BinaryHeap::HeapSize() const
{
    return size;
}
